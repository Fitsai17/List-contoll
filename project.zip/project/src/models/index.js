// src/models/index.js
const { Sequelize } = require('sequelize');
const sequelize = new Sequelize('postgres://user:weyzer@localhost:5432/postgres');  // Переконайтесь, що ці дані правильні!

const User = require('/user');
const Product = require('/product');  // Якщо є продукт, додайте відповідну модель для продуктів

// Якщо потрібно, додайте зв'язки між моделями
User.hasMany(Product);
Product.belongsTo(User);

module.exports = { sequelize, User, Product };
