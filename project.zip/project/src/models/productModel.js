// Товари для демонстрації
const products = [
    { id: 1, name: 'Меч', price: 1200 },
    { id: 2, name: 'Щит', price: 800 },
    { id: 3, name: 'Шолом', price: 500 },
    { id: 4, name: 'Лук', price: 1000 },
    { id: 5, name: 'Стріли', price: 200 },
];

module.exports = products;
