// src/services/orderService.js
const Order = require('../models/Order');

class OrderService {
  static async createOrder(userId, productId) {
    return await Order.create({ userId, productId });
  }

  static async getOrdersByUser(userId) {
    return await Order.findAll({ where: { userId } });
  }
}

module.exports = OrderService;
