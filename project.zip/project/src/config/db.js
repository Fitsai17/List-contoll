const { Sequelize } = require('sequelize');

// Налаштування з'єднання
const sequelize = new Sequelize('shop_db', 'postgres', 'weyzer', {
    host: 'localhost',
    dialect: 'postgres',
});

module.exports = sequelize;
