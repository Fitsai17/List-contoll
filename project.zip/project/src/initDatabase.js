// src/initDatabase.js
const { sequelize, User, Product } = require('./models');  // Правильний шлях до моделей

async function initializeDatabase() {
  try {
    await sequelize.authenticate();  // Перевірка з'єднання з БД
    console.log('Connection has been established successfully.');
    await sequelize.sync();  // Створює таблиці в БД, якщо вони ще не існують
    console.log('All models were synchronized successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}

initializeDatabase();
