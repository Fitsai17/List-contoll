// src/routes/orderRoutes.js
const express = require('express');
const OrderController = require('../controllers/orderController');

const router = express.Router();

router.post('/', OrderController.createOrder);
router.get('/:userId', OrderController.getOrdersByUser);

module.exports = router;
