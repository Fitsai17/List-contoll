const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// Маршрути
router.get('/', productController.getAllProducts); // Список товарів
router.get('/:id', productController.getProductById); // Конкретний товар

module.exports = router;
