// src/routes/userRoutes.js
const express = require('express');
const router = express.Router();
const { User } = require('../models');  // Імпорт моделей з папки models

// Отримати всіх користувачів
router.get('/users', async (req, res) => {
  try {
    const users = await User.findAll();
    res.json(users);
  } catch (err) {
    res.status(500).send('Error fetching users');
  }
});

// Створити нового користувача
router.post('/users', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const user = await User.create({ name, email, password });
    res.json(user);
  } catch (err) {
    res.status(500).send('Error creating user');
  }
});

module.exports = router;
