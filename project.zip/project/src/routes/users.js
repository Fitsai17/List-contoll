const express = require('express');
const User = require('src/models/user');  // Імпорт моделі користувача
const router = express.Router();

// Отримання всіх користувачів
router.get('/', async (req, res) => {
    try {
        const users = await User.findAll();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Помилка при отриманні користувачів', error });
    }
});

// Додавання нового користувача
router.post('/', async (req, res) => {
    const { name, email } = req.body;
    try {
        const newUser = await User.create({ name, email });
        res.status(201).json(newUser);
    } catch (error) {
        res.status(500).json({ message: 'Помилка при додаванні користувача', error });
    }
});

module.exports = router;
