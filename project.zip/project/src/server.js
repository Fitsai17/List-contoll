// src/server.js
const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');  // Імпорт маршруту користувачів

const app = express();
const port = 3000;

// Підключення middleware для парсингу JSON
app.use(bodyParser.json());

// Використовуємо маршрути
app.use('/api', userRoutes);  // Все, що починається з /api буде оброблятися маршрутом userRoutes

// Запуск сервера
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
