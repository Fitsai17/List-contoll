// src/controllers/orderController.js
const OrderService = require('../services/orderService');

class OrderController {
  static async createOrder(req, res) {
    const { userId, productId } = req.body;
    try {
      const order = await OrderService.createOrder(userId, productId);
      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getOrdersByUser(req, res) {
    const { userId } = req.params;
    try {
      const orders = await OrderService.getOrdersByUser(userId);
      res.status(200).json(orders);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = OrderController;
