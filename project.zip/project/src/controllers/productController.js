const products = require('../models/productModel');

// Отримати всі товари
exports.getAllProducts = (req, res) => {
    // Перевіряємо заголовок запиту: JSON чи HTML
    if (req.headers['accept'] && req.headers['accept'].includes('application/json')) {
        return res.json(products); // Відповідаємо JSON
    }

    // Відповідь у вигляді HTML-сторінки
    let html = `
        <html>
        <head>
            <title>Список товарів</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; background: #f4f4f4; padding: 20px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                table, th, td { border: 1px solid #ddd; }
                th, td { padding: 10px; text-align: left; }
                th { background-color: #3498db; color: white; }
            </style>
        </head>
        <body>
            <h1>Список товарів</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Назва</th>
                        <th>Ціна</th>
                    </tr>
                </thead>
                <tbody>
    `;
    products.forEach(product => {
        html += `
            <tr>
                <td>${product.id}</td>
                <td>${product.name}</td>
                <td>${product.price} грн</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
        </body>
        </html>
    `;

    res.send(html);
};

// Отримати конкретний товар за ID
exports.getProductById = (req, res) => {
    const id = parseInt(req.params.id, 10);
    const product = products.find(p => p.id === id);

    if (!product) {
        return res.status(404).send('Товар не знайдено');
    }

    // Перевіряємо заголовок: JSON чи HTML
    if (req.headers['accept'] && req.headers['accept'].includes('application/json')) {
        return res.json(product);
    }

    // HTML-відповідь
    res.send(`
        <html>
        <head>
            <title>${product.name}</title>
        </head>
        <body>
            <h1>${product.name}</h1>
            <p>Ціна: ${product.price} грн</p>
        </body>
        </html>
    `);
};
